
setwd("C:\\Users\\USER\\Desktop\\SLIIT\\Year_2_Sem_1\\PS\\labsheet\\IT24102609")

# import csv file
my_data <- read.csv("C:\\Users\\USER\\Downloads\\Data.csv")

# Q1
observed_counts <- c(120, 95, 85, 100)

# Q2
probabilities <- c(0.25, 0.25, 0.25, 0.25)

# Q3
chisq.test(x = observed_counts, p = probabilities)