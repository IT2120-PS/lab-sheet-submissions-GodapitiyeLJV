
#Import the dataset (’Exercise.txt’) into R and store it in a data frame called ”branch data”.
setwd("C:\\Users\\USER\\Desktop\\IT24102609")
branch_data <- read.csv("Exercise.txt", header = TRUE)
print(branch_data)


# Identify the variable type and scale of measurement for each variable.
# Variables:
# Branch -> Qualitative (Categorical), Nominal
# Sales_X1 -> Quantitative, Ratio
# Advertising_X2 -> Quantitative, Ratio
# Years_X3 -> Quantitative, Ratio


#Obtain boxplot for sales and interpret the shape

boxplot(branch_data$Sales_X1, main = "Boxplot for Sales", ylab = "Sales")

# Interpretation:
# - Check if median is centered
# - Look for outliers
# - Compare whisker lengths for skewness


#Calculate the five number summary and IQR for Advertising variable

summary(branch_data$Advertising_X2)


fivenum(branch_data$Advertising_X2)


IQR(branch_data$Advertising_X2)


#Write an R function to find the outliers in a numeric vector and check for outliers in Years

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

find_outliers(branch_data$Years_X3)



