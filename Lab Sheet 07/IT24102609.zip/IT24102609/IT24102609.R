setwd("C:\\Users\\USER\\Desktop\\SLIIT\\Year_2_Sem_1\\PS\\labsheet\\IT24102609")

punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

pexp(2, rate = 1/3, lower.tail = TRUE)

1 - pnorm(130, mean = 100, sd = 15)
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

qnorm(0.95, mean = 100, sd = 15)