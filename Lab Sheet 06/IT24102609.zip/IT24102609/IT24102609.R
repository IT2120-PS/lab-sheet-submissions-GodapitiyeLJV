setwd("C:\\Users\\USER\Desktop\\IT24102609")


n <- 50
p <- 0.85

prob_47_or_more <- pbinom(46, size = n, prob = p, lower.tail = FALSE)
cat("Exercise 1:\n")
cat("Distribution of X: Binomial(50, 0.85)\n")
cat("P(X >= 47) =", prob_47_or_more, "\n\n")

lambda <- 12

prob_15 <- dpois(15, lambda = lambda)
cat("Exercise 2:\n")
cat("Random Variable: Number of calls in one hour\n")
cat("Distribution of X: Poisson(12)\n")
cat("P(X = 15) =", prob_15, "\n")