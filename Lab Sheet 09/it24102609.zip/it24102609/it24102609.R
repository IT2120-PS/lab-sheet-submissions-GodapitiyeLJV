setwd("C:\\Users\\USER\\Desktop\\it24102609")

set.seed(123)
baking_time <- rnorm(25, mean=45, sd=2)
baking_time

mean(baking_time)
sd(baking_time)

result <- t.test(baking_time, mu=46, alternative="less")
result


result$statistic
result$p.value  
result$conf.int






